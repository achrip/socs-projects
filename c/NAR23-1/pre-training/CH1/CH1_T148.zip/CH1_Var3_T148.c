#include <stdio.h>

int main(){
    char uinput[10001]; 

    scanf("%s", uinput); 
    getchar(); 

    int number = uinput; 

    switch (strlen(uinput)){
        case 1:
            o = number/1; 

            for (int i=0; i<o)
            break; 
        case 2: 
            break; 
        case 3: 
            break; 
        case 4: 
            break; 
        case 5: 
            break; 
        default: 
            break; 

    }

}
    // while (uinput!=0){
    //     if (uinput%1000 == uinput){
    //         if (uinput%100 == uinput){
    //             if (uinput%600 == uinput){
    //                 if (uinput%50 == uinput){
    //                     if (uinput%10 == uinput){
    //                         if (uinput%9 == uinput){
    //                             if (uinput%6 == uinput){
    //                                 if (uinput%1 == uinput){
    //                                 } else {
                                        
    //                                     ell = uinput/50; 
    //                                     uinput = uinput%1000; 
    //                                     exx = uinput/10;
    //                                     uinput = uinput%1000; 
    //                                     enn = uinput/9;
    //                                     uinput = uinput%1000; 
    //                                     ess = uinput/6; 
    //                                     uinput = uinput%1000; 
    //                                     ouh = uinput/1;
    //                                     uinput = uinput%1000; 
    //                                 }
    //                             } else {}
    //                         } else {}
    //                     } else {}
    //                 } else {}
    //             } else{
    //                 cee = uinput/100;
    //                 uinput = uinput/100; 

    //             }
    //         } else{
    //             arr = uinput/600;
    //             uinput = uinput/600;
                
    //         }
    //     } else{ 
    //         emm = uinput/1000;
    //         uinput = uinput%1000; 
    //     }
    // }
        